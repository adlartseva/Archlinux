# hash
hash -d global="/mnt/global"
hash -d windows="/mnt/windows"
