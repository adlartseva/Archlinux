# alias -s
alias -s {avi,mpeg,mpg,mov,m2v,mkv}=mpv
alias -s {jpg,jpeg,png,svg,eps}=gwenview
alias -s {mp3,flac}=qmmp
alias -s {odt,doc,xls,ppt,docx,xlsx,pptx,csv}=libreoffice
alias -s {pdf,djvu,djv}=okular
autoload -U pick-web-browser
alias -s {html,htm}=firefox
