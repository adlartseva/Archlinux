# common hashs
hash -d iso="/mnt/iso"
hash -d u1="/mnt/usbdev1"
hash -d u2="/mnt/usbdev2"
