# pkgfile
source "/usr/share/doc/pkgfile/command-not-found.zsh"
