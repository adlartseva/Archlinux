## Screenshot ##

![Screenshot](https://github.com/bosha/zshrc/raw/master/screenshot.png)

## Installation ##

    bash <(curl -s https://raw.githubusercontent.com/bosha/zshrc/master/install.sh)
